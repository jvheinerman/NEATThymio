Threshold values for the blue color (the goal) in BGR:
lower range: (40, 0,0)
upper range: (255, 40, 40)

For the green color (the puck) there are multiple thresholds to assert for different environments, like differences in light and shadow. When there is a lot of green in the image, also more red/blue should be allowed to not miss the puck. The thresholds are combined by averaging the values for each presence value

Dark range in BGR:
lower range: (0, 30, 0)
upper range: (20, 255, 38)

normal range in BGR:
lower range: (0, 70, 0)
upper range: (75, 255, 70)

light range in BGR:
lower range: (0, 150, 0)
upper range: (113, 255, 133)

lighter range in BGR
lower range: (0, 200, 0)
upper range: (140, 255, 155)

